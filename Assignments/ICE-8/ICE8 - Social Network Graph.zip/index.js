import { select,selectAll,scaleOrdinal} from 'd3';

// defines all the variables that define the structure of the svg
const svg = select('svg');
const width = +svg.attr('width'); 
const height = +svg.attr('height');
const centre_x = width / 2;
const centre_y = height / 2;
const colorScale = ["pink"];

// set the structure of svg
svg.attr("preserveAspectRatio", "xMidYMid meet")
   .attr("viewBox", [0, 0, width * 2, height * 2]);

// define all nodes and markers
const defs = svg.append("defs");
		defs.selectAll("marker").data(["node"]).enter().append("marker")
				.attr("id", d => d).attr("viewBox", "0 -2.5 5 5").attr("refX", 25).attr("refY", 0).attr("markerWidth", 5).attr("markerHeight", 9)
        .attr("orient", "auto").append("path").attr("d", "M0,-2.5L5,0L0,2.5").attr("fill", "#999");

d3.json('data.json')
  .then(data => {
  
  // here we have defined links
  const links = data.links.map(d => Object.create(d));
  links.forEach((d, i) => {
    d.srcType = data.links[i].srcType;
    d.tgtType = data.links[i].tgtType;
    d.relationship = data.links[i].relationship;
    d.value = data.links[i].value;
  });
  
  //Below we have defined nodes
  const nodes = data.nodes.map(d => Object.create(d));
  nodes.forEach((d, i) => {
  	d.group = data.nodes[i].group;
  });

  // links are created here.
  const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links)
             .id(d => d.id)
             .distance(120))
      .force("charge", d3.forceManyBody()
             .strength(-500)
            )
  		.force("collision", d3.forceCollide()
             	.radius(105)
            )
      .force("center", d3.forceCenter(width, height))
  ;

  //defined events
  const drag = simulation => {
    function dragstarted(event) {
      if (!event.active) simulation.alphaTarget(0.5).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }
    function dragged(event) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }
    function dragended(event, d) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }
    return d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
  }

  const link = svg.append("g")
  .selectAll("line")
    .data(links)
  	.join("line")
  		.attr("marker-end", "url(#node)");
  
  const node = svg.append("g")
    .attr("class", "node")
  .selectAll("g")
    .data(nodes)
  	.enter()
  	.append("g")
    	.attr("transform", d => "translate(" + centre_x + ", " + centre_y + ")");
;
  
  const circles = node.append("circle")
  		.attr("r", 75)
  		.attr("fill", d => colorScale[0])
			.on("mouseover", focusNode)
			.on("mouseout", blurNode)
  		.call(drag(simulation));
  
  const nodeLbl = node.append("text")
  			.text(d => d.id)
  			.attr("dy", "0.3em");
  
 	simulation.on("tick", () => {
    link
 			.attr("x1", d => d.source.x)
 			.attr("y1", d => d.source.y)
 			.attr("x2", d => d.target.x)
 			.attr("y2", d => d.target.y);
    node
    	.attr("transform", d => "translate(" + d.x + ", " + d.y + ")");
  });
  
	function focusNode() {
	  d3.select(this).classed("nodeHover", true);
	}

	function blurNode() {
		d3.select(this).classed("nodeHover", false);
	}

});
