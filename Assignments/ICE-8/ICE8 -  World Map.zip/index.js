//importing the json libraries and  topojson file 
import { select, json, geoPath, geoNaturalEarth1} from 'd3';
import {feature} from 'topojson';

// for svg image
const svg = select('svg');

// height and width of the svg image
const width = +svg.attr('width');
const height = +svg.attr('height');

const HeaderText = "World Map";
svg.append('text').attr('y',40).attr('x',25).text(HeaderText).attr('class',"Header").attr('font-size', '20px');

//calling the geoNaturalEarth function
const projection = geoNaturalEarth1();
const pathGenerator = geoPath().projection(projection);

// create a color scale for the countries
const colorScale = d3.scaleOrdinal(d3.schemePastel1);

//for the path and shape for the world map
svg.append('path')
    .attr('class', 'sphere')
    .attr('d', pathGenerator({type: 'Sphere'}));

//below is the link for the json data with country names and the coordinates for the world map
json('https://gist.githubusercontent.com/nehabaddam/6cd52d69434b442213e9cc20c8610e9c/raw/bc011f4cb26ba285d9a78d0aed7389a7da31a25d/world-atlas.json')
    .then(data => {
      //for displaying the countries
      const countries = feature(data, data.objects.countries);

      // below lines are used for printing the world map with its respective boundaries and fill colors
      svg.selectAll('path')
        .data(countries.features)
          .enter().append('path')
          .attr('class', 'country')
          .attr('d', pathGenerator)
          .attr('fill', d => colorScale(d.properties.name))
    });
