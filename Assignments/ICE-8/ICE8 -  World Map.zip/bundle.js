(function (d3$1, topojson) {
    'use strict';

    //importing the json libraries and  topojson file 

    // for svg image
    const svg = d3$1.select('svg');

    // height and width of the svg image
    const width = +svg.attr('width');
    const height = +svg.attr('height');

    const HeaderText = "World Map";
    svg.append('text').attr('y',40).attr('x',25).text(HeaderText).attr('class',"Header").attr('font-size', '20px');

    //calling the geoNaturalEarth function
    const projection = d3$1.geoNaturalEarth1();
    const pathGenerator = d3$1.geoPath().projection(projection);

    // create a color scale for the countries
    const colorScale = d3.scaleOrdinal(d3.schemePastel1);

    //for the path and shape for the world map
    svg.append('path')
        .attr('class', 'sphere')
        .attr('d', pathGenerator({type: 'Sphere'}));

    //below is the link for the json data with country names and the coordinates for the world map
    d3$1.json('https://gist.githubusercontent.com/nehabaddam/6cd52d69434b442213e9cc20c8610e9c/raw/bc011f4cb26ba285d9a78d0aed7389a7da31a25d/world-atlas.json')
        .then(data => {
          //for displaying the countries
          const countries = topojson.feature(data, data.objects.countries);

          // below lines are used for printing the world map with its respective boundaries and fill colors
          svg.selectAll('path')
            .data(countries.features)
              .enter().append('path')
              .attr('class', 'country')
              .attr('d', pathGenerator)
              .attr('fill', d => colorScale(d.properties.name));
        });

}(d3, topojson));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vaW1wb3J0aW5nIHRoZSBqc29uIGxpYnJhcmllcyBhbmQgIHRvcG9qc29uIGZpbGUgXG5pbXBvcnQgeyBzZWxlY3QsIGpzb24sIGdlb1BhdGgsIGdlb05hdHVyYWxFYXJ0aDF9IGZyb20gJ2QzJztcbmltcG9ydCB7ZmVhdHVyZX0gZnJvbSAndG9wb2pzb24nO1xuXG4vLyBmb3Igc3ZnIGltYWdlXG5jb25zdCBzdmcgPSBzZWxlY3QoJ3N2ZycpO1xuXG4vLyBoZWlnaHQgYW5kIHdpZHRoIG9mIHRoZSBzdmcgaW1hZ2VcbmNvbnN0IHdpZHRoID0gK3N2Zy5hdHRyKCd3aWR0aCcpO1xuY29uc3QgaGVpZ2h0ID0gK3N2Zy5hdHRyKCdoZWlnaHQnKTtcblxuY29uc3QgSGVhZGVyVGV4dCA9IFwiV29ybGQgTWFwXCI7XG5zdmcuYXBwZW5kKCd0ZXh0JykuYXR0cigneScsNDApLmF0dHIoJ3gnLDI1KS50ZXh0KEhlYWRlclRleHQpLmF0dHIoJ2NsYXNzJyxcIkhlYWRlclwiKS5hdHRyKCdmb250LXNpemUnLCAnMjBweCcpO1xuXG4vL2NhbGxpbmcgdGhlIGdlb05hdHVyYWxFYXJ0aCBmdW5jdGlvblxuY29uc3QgcHJvamVjdGlvbiA9IGdlb05hdHVyYWxFYXJ0aDEoKTtcbmNvbnN0IHBhdGhHZW5lcmF0b3IgPSBnZW9QYXRoKCkucHJvamVjdGlvbihwcm9qZWN0aW9uKTtcblxuLy8gY3JlYXRlIGEgY29sb3Igc2NhbGUgZm9yIHRoZSBjb3VudHJpZXNcbmNvbnN0IGNvbG9yU2NhbGUgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lUGFzdGVsMSk7XG5cbi8vZm9yIHRoZSBwYXRoIGFuZCBzaGFwZSBmb3IgdGhlIHdvcmxkIG1hcFxuc3ZnLmFwcGVuZCgncGF0aCcpXG4gICAgLmF0dHIoJ2NsYXNzJywgJ3NwaGVyZScpXG4gICAgLmF0dHIoJ2QnLCBwYXRoR2VuZXJhdG9yKHt0eXBlOiAnU3BoZXJlJ30pKTtcblxuLy9iZWxvdyBpcyB0aGUgbGluayBmb3IgdGhlIGpzb24gZGF0YSB3aXRoIGNvdW50cnkgbmFtZXMgYW5kIHRoZSBjb29yZGluYXRlcyBmb3IgdGhlIHdvcmxkIG1hcFxuanNvbignaHR0cHM6Ly9naXN0LmdpdGh1YnVzZXJjb250ZW50LmNvbS9uZWhhYmFkZGFtLzZjZDUyZDY5NDM0YjQ0MjIxM2U5Y2MyMGM4NjEwZTljL3Jhdy9iYzAxMWY0Y2IyNmJhMjg1ZDlhNzhkMGFlZDczODlhN2RhMzFhMjVkL3dvcmxkLWF0bGFzLmpzb24nKVxuICAgIC50aGVuKGRhdGEgPT4ge1xuICAgICAgLy9mb3IgZGlzcGxheWluZyB0aGUgY291bnRyaWVzXG4gICAgICBjb25zdCBjb3VudHJpZXMgPSBmZWF0dXJlKGRhdGEsIGRhdGEub2JqZWN0cy5jb3VudHJpZXMpO1xuXG4gICAgICAvLyBiZWxvdyBsaW5lcyBhcmUgdXNlZCBmb3IgcHJpbnRpbmcgdGhlIHdvcmxkIG1hcCB3aXRoIGl0cyByZXNwZWN0aXZlIGJvdW5kYXJpZXMgYW5kIGZpbGwgY29sb3JzXG4gICAgICBzdmcuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgLmRhdGEoY291bnRyaWVzLmZlYXR1cmVzKVxuICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2NvdW50cnknKVxuICAgICAgICAgIC5hdHRyKCdkJywgcGF0aEdlbmVyYXRvcilcbiAgICAgICAgICAuYXR0cignZmlsbCcsIGQgPT4gY29sb3JTY2FsZShkLnByb3BlcnRpZXMubmFtZSkpXG4gICAgfSk7XG4iXSwibmFtZXMiOlsic2VsZWN0IiwiZ2VvTmF0dXJhbEVhcnRoMSIsImdlb1BhdGgiLCJqc29uIiwiZmVhdHVyZSJdLCJtYXBwaW5ncyI6Ijs7O0lBQUE7QUFHQTtJQUNBO0lBQ0EsTUFBTSxHQUFHLEdBQUdBLFdBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxQjtJQUNBO0lBQ0EsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2pDLE1BQU0sTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNuQztJQUNBLE1BQU0sVUFBVSxHQUFHLFdBQVcsQ0FBQztJQUMvQixHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQy9HO0lBQ0E7SUFDQSxNQUFNLFVBQVUsR0FBR0MscUJBQWdCLEVBQUUsQ0FBQztJQUN0QyxNQUFNLGFBQWEsR0FBR0MsWUFBTyxFQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3ZEO0lBQ0E7SUFDQSxNQUFNLFVBQVUsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNyRDtJQUNBO0lBQ0EsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDbEIsS0FBSyxJQUFJLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQztJQUM1QixLQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRDtJQUNBO0FBQ0FDLGFBQUksQ0FBQyw4SUFBOEksQ0FBQztJQUNwSixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUk7SUFDbEI7SUFDQSxNQUFNLE1BQU0sU0FBUyxHQUFHQyxnQkFBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzlEO0lBQ0E7SUFDQSxNQUFNLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO0lBQzNCLFNBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7SUFDakMsV0FBVyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ2pDLFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7SUFDbkMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLGFBQWEsQ0FBQztJQUNuQyxXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFDO0lBQzNELEtBQUssQ0FBQzs7OzsifQ==