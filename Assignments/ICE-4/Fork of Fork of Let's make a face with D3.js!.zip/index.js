import { select, arc } from 'd3';

const svg = select('svg');

const width = +svg.attr('width');
const height = +svg.attr('height');

// adding a face
const g = svg.append('g')  
  .attr('transform', `translate(${width / 2}, ${height / 2})`);

const circle = g.append('circle');

circle.attr('r', 160 );
circle.attr('fill', 'mistyrose');
circle.attr('stroke', 'white');

arc({
  innerRadius: 0,
  outerRadius: 40,
  startAngle: 0,
  endAngle: Math.PI /6
});

// Adding Ears left and right

const earsYOffset = -30;
const earRadiusX = 30;
const earRadiusY = 40;

const leftEar = g.append('ellipse');
leftEar.attr('rx', earRadiusX);
leftEar.attr('ry', earRadiusY);
leftEar.attr('fill', 'mistyrose');
leftEar.attr('stroke', 'white');
leftEar.attr('cx', -187);
leftEar.attr('cy', earsYOffset);

const rightEar = g.append('ellipse');
rightEar.attr('rx', earRadiusX);
rightEar.attr('ry', earRadiusY);
rightEar.attr('fill', 'mistyrose');
rightEar.attr('stroke', 'white');
rightEar.attr('cx', 187);
rightEar.attr('cy', earsYOffset);

//added eyes left and right

const eyeSpacing = 60;
const eyeYOffset = -60;
const eyeRadius = 15;
const eyebrowWidth = 50;
const eyebrowHeight = 10;
const eyebrowYOffset = -60;

const eyesG = g
  .append('g')
  .attr('transform', `translate(0, ${eyeYOffset})`);

const leftEye = eyesG
  .append('g')
  .attr('transform', `translate(${-70}, 0)`);

leftEye
  .append('path')
  .attr('d', 'M 0 0 Q 20 20, 40 0')
  .attr('stroke', 'black')
  .attr('stroke-width', 3)
  .attr('fill', 'none')
  .attr('cx', -50);

const rightEye = eyesG
  .append('g')
  .attr('transform', `translate(${40}, 0)`);

rightEye
  .append('path')
  .attr('d', 'M 0 0 Q 20 20, 40 0')
  .attr('stroke', 'black')
  .attr('stroke-width', 3)
  .attr('fill', 'none')
  .attr('cx', -50);

// Added eyebrows both left and right

const eyebrowsG = eyesG
  .append('g')
  .attr('transform', `translate(0, ${eyebrowYOffset})`);

eyebrowsG
  .transition().duration(4000)
  .attr('transform', `translate(0, ${eyebrowYOffset - 50})`)
  .transition().duration(4000)
  .attr('transform', `translate(0, ${eyebrowYOffset})`);

const leftEyebrow = eyebrowsG
  .append('rect')
  .attr('x', -eyeSpacing - eyebrowWidth / 2)
  .attr('width', eyebrowWidth)
  .attr('height', eyebrowHeight);


const rightEyebrow = eyebrowsG
  .append('rect')
    .attr('x', eyeSpacing - eyebrowWidth / 2)
    .attr('width', eyebrowWidth)
    .attr('height', eyebrowHeight); 

// Adding nose
const nose = g.append('circle');
nose.attr('r', 5);
nose.attr('fill', 'black');
nose.attr('stroke', 'brown');
nose.attr('cy', -20);

//Adding mouth
const mouth = g
  .append('path')
  .attr('d', arc()({
      innerRadius: 60,
      outerRadius: 0,
      startAngle: Math.PI / 2,
      endAngle: Math.PI * 3/2
    }));

//Added teeth inside mouth
const teeth = g
  .append('g')
    .attr('transform', 'translate(0, 50)');

const teethWidth = 10;
const teethHeight = 10;
const teethSpacing = 0;

for (let i = 0; i < 4; i++) {
  teeth
    .append('rect')
      .attr('x', -40 / 2 + i * (teethWidth + teethSpacing))
      .attr('y', -48)
      .attr('width', teethWidth)
      .attr('height', teethHeight)
      .attr('fill', 'white')
      .attr('stroke', 'black');
}

//added tongue inside mouth
const tongue = g.append('path')
  .attr('d', arc()({
    innerRadius: 0,
    outerRadius: 30,
    startAngle: Math.PI / 2,
    endAngle: Math.PI * 3/2
  }))
  .attr('fill', 'red')
  .attr('transform', 'translate(0, 40)');

// Added hair
const hair1 = g.append('rect')
  .attr('width', 60)
  .attr('height', 10)
  .attr('x', -190)
  .attr('y', -100)
  .attr('fill', 'black')
  .attr('transform', 'rotate(50)');

const hair2 = g.append('rect')
  .attr('width', 60)
  .attr('height', 10)
  .attr('x', -190)
  .attr('y', -100)
  .attr('fill', 'black')
  .attr('transform', 'rotate(30)');

const hair3 = g.append('rect')
  .attr('width', 60)
  .attr('height', 10)
  .attr('x', -190)
  .attr('y', -100)
  .attr('fill', 'black')
  .attr('transform', 'rotate(40)');


//Adding hat using rect and polygon
const hat = g.append('g')
  .attr('transform', 'translate(0, -220)');

const hatWidth = 120;
const hatHeight = 40;
const hatTopHeight = 20;
const hatColor = 'black';

hat.append('rect')
  .attr('width', hatWidth)
  .attr('height', hatHeight)
  .attr('fill', hatColor)
  .attr('stroke', 'blue')
  .attr('x', 10 )
  .attr('y', 10)
  .attr('transform', 'rotate(20)');

hat.append('polygon')
  .attr('points', `-${30},-${90} ${20},-${hatHeight} 0,-${hatHeight - hatTopHeight}`)
  .attr('width', hatWidth)
  .attr('height', hatHeight)
  .attr('fill', hatColor)
  .attr('stroke', 'blue')
  .attr('transform', 'rotate(130)');


// Adding collar
const collar = g.append('rect')
  .attr('width', 200)
  .attr('height', 10)
  .attr('fill', 'brown')
  .attr('stroke', 'white')
  .attr('x', 10 )
  .attr('y', -30)
  .attr('transform', 'translate(-100, 190)');















