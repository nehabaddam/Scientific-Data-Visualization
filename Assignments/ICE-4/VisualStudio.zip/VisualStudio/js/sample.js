let userId = prompt("Please enter your ID: ");

alert("Your ID is: " + userId);

