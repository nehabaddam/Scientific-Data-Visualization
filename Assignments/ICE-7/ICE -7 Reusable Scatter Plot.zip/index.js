import { csv, select } from 'd3';
import { scatterPlot } from './scatterPlot';

const csvUrl = [
  'https://gist.githubusercontent.com/nehabaddam/fdb946a76c5d71b79fe33eb16d304332/raw/e602d28100cffd2c5f0b496954217288c6e134e2/iris.csv',
].join('');
const parseRow = (d) => {
  d.sepal_length = +d.sepal_length;
  d.sepal_width = +d.sepal_width;
  d.petal_length = +d.petal_length;
  d.petal_width = +d.petal_width;
  return d;
};

const width = window.innerWidth;
const height = window.innerHeight;
const svg = select('body')
  .append('svg')
  .attr('width', width)
  .attr('height', height);

const margin = {
  top: 20,
  right: 20,
  bottom: 40,
  left: 50,
};

// Append x-axis label
svg.append('text')
  .attr('x', width / 2)
  .attr('y', height - margin.bottom / 30)
  .attr('text-anchor', 'middle')
  .text('Petal Width');

// Append y-axis label
svg.append('text')
  .attr('x', -height / 2)
  .attr('y', margin.left / 3)
  .attr('text-anchor', 'middle')
  .attr('transform', 'rotate(-90)')
  .text('Sepal Length');

const main = async () => {
  const plot = scatterPlot()
    .width(width)
    .height(height)
    .data(await csv(csvUrl, parseRow))
    .xValue((d) => d.petal_width)
    .yValue((d) => d.sepal_length)
  	.symbolValue((d) => d.species)
    .margin(margin)
    .radius(5);

  svg.call(plot);

  const columns = [
    'petal_width',
    'sepal_width',
    'petal_length',
    'sepal_length',
  ];
  
  let i = 0;
  setInterval(() => {
    plot.xValue((d) => d[columns[i % columns.length]]);
    svg.call(plot);
    i++;
  }, 15000);
};
main();
