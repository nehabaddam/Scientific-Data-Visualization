A reusable scatter plot inspired by [Towards Reusable Charts](https://bost.ocks.org/mike/chart/).

Shows the [Iris Dataset](https://gist.github.com/curran/a08a1080b88344b0c8a7).
