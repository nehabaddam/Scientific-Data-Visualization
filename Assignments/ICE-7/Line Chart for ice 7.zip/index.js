// Import required modules from D3
import {
  select,
  csv,
  scaleLinear,
  scaleTime,
  extent,
  axisLeft,
  axisBottom,
  line,
  max
} from 'd3';

const svg = select('svg');

const width = +svg.attr('width');
const height = +svg.attr('height');

// Formatting the total value to show on the Linechart
const xAxisTickFormat = number =>
    format('.3s')(number)

const render = data => { 
// Assigning X axis data   
  const xValue = d => d.Year; 
  const xAxisLabel = 'Year';
// Assigning Y axis data 
  const yValue = d => d.Sales;
  const yAxisLabel = 'Sales';
  
  const margin = { top: 10, right: 40, bottom: 88, left: 120 };//mm manière que CSS
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top-30 - margin.bottom-20;
  
  // Determing the Scale for X axis
  const xScale = scaleTime()
    .domain(extent(data, xValue)) 
    .range([0, innerWidth]) 
    .nice(); //round values out
  
// Determing the Scale for Y axis  
  const yScale = scaleLinear()
    .domain([0, max(data, yValue )])
    .range([innerHeight, 0])
    .nice();

// POsitioning the svg element  
  const g = svg.append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);
 // Assigning values to x axis  
  const xAxis = axisBottom(xScale)
    .tickSize(-innerHeight)
    .tickPadding(20);
 // Assigning values to y axis  
  const yAxis = axisLeft(yScale)
    .tickSize(-innerWidth)
    .tickPadding(10)
  ;

  const yAxisG = g.append('g').call(yAxis);
  	yAxisG.selectAll('.domain').remove();
  
  yAxisG.append('text')
      .attr('class', 'axis-label')
      .attr('y', -90)
      .attr('x', -innerHeight / 3)
      .attr('fill', 'black')
      .attr('transform', `rotate(-90)`)
      .text(yAxisLabel);
  
  const xAxisG = g.append('g').call(xAxis)
    	.attr('transform', `translate(0,${innerHeight})`);
  
  xAxisG.select('.domain').remove();
  
  xAxisG.append('text')
      .attr('class', 'axis-label')
      .attr('y', 70)
      .attr('x', innerWidth / 2)
      .attr('fill', 'black')
      .text(xAxisLabel);

// Drawing a line and adding it to svg 
  
  const lineGenerator = line()
  	.x(d => xScale(xValue(d)))
  	.y(d => yScale(yValue(d)));
  
  g.append('path')
  	.attr('class', 'line_path')
  	.attr('d', lineGenerator(data))
};

// Loading and Parsing CSV data
csv('https://gist.githubusercontent.com/nehabaddam/66696081c1deb0d72a4c58a83733c59b/raw/dc0b908a3c8ddf0af5b33b3f619f0f596194c107/store.csv')
  .then(data => {
    data.forEach(d => {
    	d.Sales = +d.Sales;
//Formatting to retrieve year from the date
      d.Year = d3.timeParse("%Y-%m-%d")(d.Year);
    });

    render(data);
  })