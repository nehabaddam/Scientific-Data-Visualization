(function (d3$1) {
  'use strict';

  // Colors for the sections in Pie Chart
  const sectionColors = [
    		'red', 'blue', 'yellow', 'lime', 'orange', 'skyblue', 'crimson', 'wheat', 'turquoise', 'aqua'
  		  ];

  // Data set URI
  const csvUrl ='https://gist.githubusercontent.com/nehabaddam/689ba2012b149f94960a7b4e2111892d/raw/660a9240fe7da8b4f183079d98625106e7be40bd/covid_deaths.csv';
  const fetchData = async () => {
    const data = await d3$1.csv(csvUrl);
    return data;
  };

  // Select the SVG from the HTML body
  const svg = d3$1.select("svg");
  const width = + svg.attr('width');
  const height = + svg.attr('height');

  // Format axes text
  const xAxisTickFormat = number =>
    	d3$1.format('.4~g')(number);

  // Render Pie Chart on the canvas
  const render = (data, total) => {
    const pieData = d3$1.pie().value(d=>d.Deaths)(data);
    const colors = d3$1.scaleOrdinal()
    	.domain(data)
    	.range(sectionColors);
    
    // Object for generating Arcs of the sections
    const arcGenerator = d3.arc()
    .innerRadius(0)
    .outerRadius(250);

    // Segments are the partition in the Pie Chart
  	const segments = d3$1.arc()
    	.innerRadius(0)
    	.outerRadius(175)
    	.padAngle(0)
    	.padRadius(0);
    
    const sections = svg.append("g")
    	.attr("transform", `translate(250,250)`)
    	.selectAll("path").data(pieData);
    
    sections.enter()
      .append("path")
      .attr("d", segments)
    	.attr("fill", d => colors(d.data.Deaths));
    
    // Render text on each section
    sections
      .enter()
      .append('text')
      .text(d => xAxisTickFormat((d.data.Deaths/1000))+"K")
      .attr("transform", function(d) { return "translate(" + arcGenerator.centroid(d) + ")";  })
      .style("text-anchor", "middle")
    	.style('fill', 'black')
      .style("font-size", 15);
    
    // Render legend for the data
    const legends = svg.append("g")
    	.attr("transform", "translate(500,100)")
      .selectAll(".legends").data(pieData);
    
    const legend = legends.enter().append("g").classed(".legends",true)
    	.attr("transform", (d,i)=>{
        return `translate(0,${(i+1)*30})`;
      });
    
    // Formats the legend for Deaths
    legend.append("rect").attr("width",20).attr("height",20)
    	.attr("fill", d => colors(d.data.Deaths));
    
    legend.append("text")
    	.attr("x", 250)
    	.attr("y", 15)
    	.attr("class","legend_value")
    	.text(d=>xAxisTickFormat((d.data.Deaths/1000))+"K");
    
    // Formats the legend for Countries 
    legend.append("text")
    	.attr("x", 25)
    	.attr("y", 15)
    	.attr("class","legend_text")
    	.text(d => d.data.Country);
  };
  // Main function
  const run = async () => {
    let data = await fetchData();
    let total = 0;
    data.forEach(d=>{
      d.Deaths = +d.Deaths;
      total += d.Deaths;
    });
  	render(data);
  };
  run();

}(d3));
