import {
  select,
  csv,
  scaleLinear,
  scaleTime,
  extent,
  axisLeft,
  axisBottom,
  format,
  line,
  area,
  curveBasis
} from 'd3';

const svg = select('svg');

const width = +svg.attr('width');
const height = +svg.attr('height');

// Formatting the total value to show on the Areachart
const xAxisTickFormat = number =>
    format('.3s')(number)

const render = data => {
  
  const xValue = d => d.Year;
  const xAxisLabel = 'Month-Year';
  
  const yValue = d => d.Sales;
  const circleRadius = 7;
  const yAxisLabel = 'Transaction Amount';
  
  const margin = { top: 10, right: 40, bottom: 88, left: 150 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;  
// Determing the Scale for X axis
  const xScale = scaleTime()
    .domain(extent(data, xValue))
    .range([0, innerWidth])
    .nice();
// Determing the Scale for Y axis  
  const yScale = scaleLinear()
    .domain(extent(data, yValue))
    .range([innerHeight, 0])
    .nice();
 // POsitioning the svg element   
  const g = svg.append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);
 // Assigning values to x axis 
  const xAxis = axisBottom(xScale)
    .tickSize(-innerHeight)
    .tickPadding(15);
  
 // Assigning values to y axis  
  const yAxis = axisLeft(yScale)
    .tickSize(-innerWidth)
    .tickPadding(10)
    .tickFormat(xAxisTickFormat);
  
  const yAxisG = g.append('g').call(yAxis);
  yAxisG.selectAll('.domain').remove();
  
  yAxisG.append('text')
      .attr('class', 'axis-label')
      .attr('y', -93)
      .attr('x', -innerHeight / 2)
      .attr('transform', `rotate(-90)`)
      .attr('text-anchor', 'middle')
      .text(yAxisLabel);
  
  const xAxisG = g.append('g').call(xAxis)
    .attr('transform', `translate(0,${innerHeight})`);
  
  xAxisG.append('text')
      .attr('class', 'axis-label')
      .attr('y', 75)
      .attr('x', innerWidth / 2)
      .text(xAxisLabel);
 // To draw the line on the curve   and adding it to svg 
  const lineGenerator = line()
  	.x(d => xScale(xValue(d)))
  	.y(d => yScale(yValue(d)))
  	.curve(curveBasis);
 // To draw the area under the curve and adding it to svg 
  const areaGenerator = area()
  	.x(d => xScale(xValue(d)))
  	.y0(innerHeight)
  	.y1(d => yScale(yValue(d)))
  	.curve(curveBasis);
  
  g.append('path')
  	.attr('class', 'line-chart')
  	.attr('d', lineGenerator(data));
  
  g.append('path')
  	.attr('class', 'area-chart')
  	.attr('d', areaGenerator(data));
  
 
};
// Loading and Parsing CSV data
csv('https://gist.githubusercontent.com/nehabaddam/66696081c1deb0d72a4c58a83733c59b/raw/dc0b908a3c8ddf0af5b33b3f619f0f596194c107/store.csv')
  .then(data => {
    data.forEach(d => {
      d.Sales = +d.Sales;
//Formatting to retrieve year from the date
      d.Year = d3.timeParse("%Y-%m-%d")(d.Year);
    });
    render(data);
  	console.log(data);
  });