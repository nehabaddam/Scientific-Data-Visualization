from flask import Flask, render_template, request 
import pandas as pd
import json
#importing utility libraries
import warnings
#importing model
from model import Chart
from obesity import Obesity
#importing classifier


from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report,accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler

# Define a Flask app
app = Flask(__name__)

global gl_fig, low, high

global world_map,female_map,male_map

#ignoring all warnings
warnings.filterwarnings("ignore")  

df = pd.read_csv("obesity_data.csv", delimiter=",", header=0)
df.head()

df_cleaned = df 

df_scaled=df_cleaned.copy()

columns_to_scale = ['Gender','Age','Height','Weight','family_history_with_overweight','FAVC','FCVC','NCP','CAEC','SMOKE','CH2O','SCC','FAF','TUE','CALC','MTRANS']

scaler = StandardScaler()
df_scaled[columns_to_scale] = scaler.fit_transform(df_cleaned[columns_to_scale])

#we perform some Standardization using minmaxscaler
df_scaled_mm=df_cleaned.copy()

columns_to_scale_mm = ['Gender','Age','Height','Weight','family_history_with_overweight','FAVC','FCVC','NCP','CAEC','SMOKE','CH2O','SCC','FAF','TUE','CALC','MTRANS']

mmscaler = MinMaxScaler()
df_scaled_mm[columns_to_scale_mm] = mmscaler.fit_transform(df_cleaned[columns_to_scale_mm])

X = df_cleaned.drop(['NObeyesdad'], axis=1) #features 
y = df_cleaned['NObeyesdad']  #target feature


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)


# Hyperparameter Tuning using GridSearchCV
param_grid = {
    'n_estimators': [500],
    'max_depth': [20],
    'max_features': ['log2'],
    'max_leaf_nodes': [500]
}

rf = RandomForestClassifier()
rf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = rf.predict(X_test)

# Print accuracy score, confusion matrix, and classification report
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)
tpr = cm[1][1] /(cm[1][0] + cm[1][1])
print("True Positive Rate:", tpr)
report = classification_report(y_test, y_pred)
print("Classification Report:\n", report)


# Define a route for the homepage
@app.route('/')
def index():
    output = {'Gender':[1], 'Age':[25], 'Height':[120], 'Weight':[120], 'family_history_with_overweight':[1], 'FAVC':[1], 'FCVC':[1],
       'NCP':[3], 'CAEC':[], 'SMOKE':[1], 'CH2O':[3], 'SCC':[1], 'FAF':[1], 'TUE':[4], 'CALC':[], 'MTRANS':[]}
    return render_template('index.html', output = output)

# Define a route for the prediction page
@app.route('/predict', methods=['POST'])
def predict():

    d = {'Gender':[], 'Age':[], 'Height':[], 'Weight':[], 'family_history_with_overweight':[], 'FAVC':[], 'FCVC':[],
       'NCP':[], 'CAEC':[], 'SMOKE':[], 'CH2O':[], 'SCC':[], 'FAF':[], 'TUE':[], 'CALC':[], 'MTRANS':[]}
    output = request.form.to_dict()

    d["Gender"].append(int(output["Gender"]))
    d["Age"].append(int(output["Age"]))
    d["Height"].append(int(output["Height"]))
    d["Weight"].append(int(output["Weight"]))
    d["family_history_with_overweight"].append(int(output["family_history_with_overweight"]))
    d["FAVC"].append(int(output["FAVC"]))
    d["FCVC"].append(int(output["FCVC"]))
    d["NCP"].append(int(output["NCP"]))
    d["CAEC"].append(int(output["CAEC"]))
    d["SMOKE"].append( int(output["SMOKE"]))
    d["CH2O"].append(int(output["CH2O"]))
    d["SCC"].append(int(output["SCC"]))
    d["FAF"].append(int(output["FAF"]))
    d["TUE"].append(int(output["TUE"]))
    d["CALC"].append( int(output["CALC"]))
    d["MTRANS"].append(int(output["MTRANS"]))

    df1 = pd.DataFrame(d)
    pred = rf.predict(df1)

    if pred[0]==1:
      note = "Normal weight"
    elif pred[0]==2:
      note = "Overweight I"
    elif pred[0]==3:
      note = "Overweight II"
    elif pred[0]==4:
      note = "Obesity I"
    elif pred[0]==5:
      note = "Obesity II"
    elif pred[0]==6:
      note = "Obesity III"
    elif pred[0]==7:
      note = "Insufficient Weight"
    else:
      note = "No result"
    return render_template('index.html', prediction= note, output=output )

#analyze function
@app.route('/analyze', methods=['GET'])
def analyze():
    global gl_fig, low,high
    chart = Chart()
    fig = chart.main_world() 
    gl_fig = fig.to_html(full_html=False)
    high = chart.highest()
    high = high.to_html(full_html=False)
    low = chart.lowest()
    low = low.to_html(full_html=False)
    return render_template('analyze.html', fig=gl_fig)

#highest function to display highest obesity countries
@app.route('/highest')
def highest():
    global gl_fig,low,high
    return render_template('analyze.html', fig=gl_fig, high = high)

#lowest function to display lowest obesity countries
@app.route('/lowest')
def lowest():
    global gl_fig,low,high
    return render_template('analyze.html', fig=gl_fig, high = low, low = high)

#lowest function to display regional obesity countries
@app.route('/region')
def region():
    global gl_fig,low,high
    chart = Chart()
    reg = chart.regions()
    region = reg.to_html(full_html=False)
    return render_template('analyze.html', fig=gl_fig, high = region, low = low)

#obesity function to display obesity form data and fetch data from form
@app.route('/obesity', methods=['GET', 'POST'])
def obesity():
    obesity = Obesity()
    if request.method == 'POST':
      option = request.form.get('option')
      if option == 'obesity':
        fig = obesity.obesity()
      elif option == 'Age':
        fig = obesity.age()
      elif option == 'Height':
        fig = obesity.height()
      elif option == 'Weight':
        fig = obesity.weight()
      elif option == 'FHO':
        fig = obesity.fho()
      elif option == 'FAVC':
        fig = obesity.favc()
      elif option == 'FCVC':
        fig = obesity.fcvc()
      elif option == 'NCP':
        fig = obesity.ncp()
      elif option == 'CAEC':
        fig = obesity.caec()
      elif option == 'SMOKE':
        fig = obesity.smoke()
      elif option == 'CH2O':
        fig = obesity.water()
      elif option == 'SCC':
        fig = obesity.calories()
      elif option == 'FAF':
        fig = obesity.physical()
      elif option == 'TUE':
        fig = obesity.tue()
      elif option == 'CALC':
        fig = obesity.alcohol()
      elif option == 'MTRANS':
        fig = obesity.mtrans()
    else:
      fig = obesity.obesity()
    
    figure = fig.to_html(full_html=False)
    return render_template('obesity.html', fig=figure)

#chart function to display world maps
@app.route('/chart', methods=['GET', 'POST'])
def chart():
    chart = Chart()
    if request.method == 'POST':
      gender = request.form.get('gender')
      if gender == 'Male':
        fig, unique_countries = chart.male()
      elif gender == 'Female':
        fig, unique_countries = chart.female()
      else:
        fig, unique_countries = chart.world()   
    else:
      fig, unique_countries = chart.world()
    figure = fig.to_html(full_html=False)
    return render_template('charts.html', fig=figure, countries = unique_countries)

#charttable function to dcountry specific data
@app.route('/chart_table', methods=['GET', 'POST'])
def chart_table():
    chart = Chart()
    if request.method == 'POST':
      fig, unique_countries = chart.world()  
      country = request.form.get('country')
      line = chart.line_bar(country)
    figure = fig.to_html(full_html=False)
    line = json.dumps(line.to_dict())
    return render_template('interactive.html', fig=figure, line=line, countries = unique_countries)

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
